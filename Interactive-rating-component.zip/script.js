const mainContainer = document.querySelector(".container")
const thanks = document.querySelector(".thankyou")
const submitButton = document.getElementById("submit")
const rating = document.getElementById("rating")
const rates = document.querySelectorAll(".btn-rate")

submitButton.addEventListener("click", () => {
  thanks.classList.remove("hidden")
  mainContainer.style.display = "none";
});

rates.forEach((rate) => {
  rate.addEventListener("click", () => {
   rating.innerHTML = rate.innerHTML
  })
});